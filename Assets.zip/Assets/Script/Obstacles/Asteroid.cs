using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Asteroid : MonoBehaviour
{
    public void Initialize(string asteroidName, Vector3 position)
    {
        transform.position = position; //Asteroid is Initialized 

        gameObject.name = asteroidName; //Add more logic
    }
}
