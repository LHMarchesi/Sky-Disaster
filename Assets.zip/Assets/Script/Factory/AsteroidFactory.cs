using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AsteroidFactory : MonoBehaviour
{
    [SerializeField] private List<AsteroidsScriptable> asteroidDataList; //ScriptableObjects
    
    private Dictionary<string, AsteroidsScriptable> asteroidPool = new Dictionary<string, AsteroidsScriptable>();

    public AsteroidsScriptable GetAsteroidData(string asteroidName)
    {
        if (!asteroidPool.ContainsKey(asteroidName))
        {
            AsteroidsScriptable asteroidData = asteroidDataList.Find(data => data.name == asteroidName);  // Looks in the list of asteroids
            
            if (asteroidData != null)
            {
                asteroidPool[asteroidName] = asteroidData;
            }
        }

        return asteroidPool.ContainsKey(asteroidName) ? asteroidPool[asteroidName] : null;
    }
}
